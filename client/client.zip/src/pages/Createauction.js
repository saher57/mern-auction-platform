import React from 'react';
import AuctionForm from '../components/AuctionForm';


const CreateAuction = () => {
  return (
    <div style={{ padding: '20px' }}>
      
      <AuctionForm />
    </div>
  );
};

export default CreateAuction;