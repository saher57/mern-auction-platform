import React from 'react';
import AdminPanel from '../components/AdminPanel';

const Admin = () => {
  return (
    <div style={{ padding: '20px' }}>
      <AdminPanel />
    </div>
  );
};

export default Admin;