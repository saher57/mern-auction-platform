# Auction Platform

A full-stack auction platform built with the MERN stack.

## Features
- User authentication (register/login)
- Create and bid on auctions
- Real-time bidding updates with Socket.IO
- Payment processing with Stripe
- Admin panel for dispute resolution

## Setup Instructions
1. **Clone the repository**:
   ```bash
   git clone <repo-url>
   cd auction-platform